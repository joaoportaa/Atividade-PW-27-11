<?php
class HomeController {
    public function index() {
        view('home.php');
    }
}